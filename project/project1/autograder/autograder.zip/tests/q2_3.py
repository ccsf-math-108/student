test = {   'name': 'q2_3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> 10<=poverty_percent<=20\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.allclose(np.round(poverty_percent, 2), 14.3)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
