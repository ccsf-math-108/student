OK_FORMAT = True

test = {   'name': 'task_01',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> sum_scores(14, 7, 3, 0, 3) == 27 and sum_scores(2, 3, 6, 1, 0) == 12\nTrue',
                                       'failure_message': "❌ Your function doesn't seem to work correctly with our 4 quarter scores and over time score.",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ Your function works with our 4 quarter scores and over time score.'},
                                   {'code': '>>> \n>>> sum_scores(1, 1, 1, 1, 3) == 7\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
