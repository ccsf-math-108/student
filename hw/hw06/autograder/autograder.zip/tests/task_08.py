OK_FORMAT = True

test = {   'name': 'task_08',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> 0 <= no_green <= 1\nTrue',
                                       'failure_message': '❌ no_green should be a numerical value between 0 and 1, inclusive.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ no_green is a numerical value between 0 and 1, inclusive.'},
                                   {'code': '>>> \n>>> np.isclose(no_green, (1 - (2 / 38)) ** 10)\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
