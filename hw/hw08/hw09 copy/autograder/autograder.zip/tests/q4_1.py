test = {   'name': 'q4_1',
    'points': None,
    'suites': [{'cases': [{'code': '>>> np.round(initial_sample_mean) == 74\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
