test = {   'name': 'q11',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> # Make sure your function has the proper syntax!\n>>> to_percentage(.35) == 35.0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
