test = {   'name': 'q36',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> import math\n>>> math.isclose(average_pay_2014, 11649176.115603436, rel_tol = 10)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
