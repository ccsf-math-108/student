test = {   'name': 'q42',
    'points': None,
    'suites': [{'cases': [{'code': '>>> num_ceos_more_than_30_million_2 == 5\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
