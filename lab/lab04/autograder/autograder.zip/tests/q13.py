test = {   'name': 'q13',
    'points': None,
    'suites': [{'cases': [{'code': '>>> disemvowel("Datascience rules!") == "Dtscnc rls!"\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
